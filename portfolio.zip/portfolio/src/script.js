function showPage(pageId) {
    const pages = document.querySelectorAll('.page');

    pages.forEach(page => {
        if (page.classList.contains('active')) {
            page.classList.remove('active');
            page.classList.add('exit');
        }
    });

    setTimeout(() => {
        pages.forEach(page => page.classList.remove('exit'));
        document.getElementById(pageId).classList.add('active');
    }, 600);
}
